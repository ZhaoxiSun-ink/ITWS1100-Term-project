$(document).ready(function() {
    $("#save").click(function ()  {
        var name = $("#name").val();
        var password = $("#password").val(); 
        $.ajax({
            type:'GET',
            url: 'usersdata.json',
            dataType:"json",
            error:function(){alert("fail")},
            success:function(data){
                console.log(data);
                var len = data.user.length;
                for (var i = 0; i <len; i++){
                    if(name == data.user[i].name){
                        alert("Already have this userName. Please try another one."); 
                        return;  
                    }
                }
                data.user.push({"name":name, "password":password});
                console.log(data);
                alert("Register Sucessful.")
            }
        })
    });
});