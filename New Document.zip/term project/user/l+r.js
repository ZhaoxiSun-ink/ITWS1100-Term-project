var userdata = {user:[
    {"email":"z@outlook.com","name": "Z","password": "12345"},
	{"email":"a@outlook.com","name": "A","password": "12345"}
]};

$("#login").click(function ()  {
    var name = $("#name").val();
    var password = $("#password").val();
    var len = userdata.user.length;
    for (var i = 0; i <len; i++){
        if(name == data.user[i].name && password == data.user[i].password){
            alert("login succcessful.");
            return;
        }
    }
    alert("login fail");
});

$("#register").click(function(){
    var mail = $("#mail").val();
    var name = $("#name").val();
    var password = $("#password").val();
    var len = userdata.user.length;
    for (var i = 0; i <len; i++){
        if(name == data.user[i].name){
            alert("Already have this userName. Please try another one.");
            return;
        }
    }
    data.user.push({"email":mail, "name":name, "password":password});
    console.log(data);
    alert("Register Sucessful.")
});